package com.example.adhantv;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** Choose house pin via Android TV DPAD; map stays north-up, and Qibla is geographic bearing. */
public final class MapActivity extends Activity {
    private QiblaMapView map;
    private TextView instructions;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,8,18,8);root.setBackgroundColor(0xFF0A1C2A);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        instructions=new TextView(this);instructions.setTextColor(0xFFF1C97E);instructions.setTextSize(19);
        instructions.setGravity(Gravity.CENTER);root.addView(instructions);
        map=new QiblaMapView(this,Config.lat(this),Config.lon(this));
        root.addView(map,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);
        Button increase=button("تكبير +",()->map.setZoom(map.getZoom()+1));
        Button decrease=button("تصغير −",()->map.setZoom(map.getZoom()-1));
        Button select=button("حفظ الموقع عند الدائرة البيضاء",this::savePoint);
        Button exit=button("العودة دون حفظ",this::finish);
        controls.addView(increase);controls.addView(decrease);controls.addView(select);controls.addView(exit);
        root.addView(controls);setContentView(root);
        map.setChangeListener((lat,lon)->updateLabel());updateLabel();map.requestFocus();
    }
    private Button button(String title,Runnable onClick){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(17);
        b.setOnClickListener(v->onClick.run());return b;
    }
    private void updateLabel(){
        double heading=Qibla.bearing(map.lat(),map.lon());
        instructions.setText(String.format(Locale.US,
            "القبلة: %.1f° من الشمال الحقيقي (%s) • حرّك الموقع بالأسهم، OK للحفظ • %.5f, %.5f",
            heading,Qibla.direction(heading),map.lat(),map.lon()));
    }
    private void savePoint(){
        Config.prefs(this).edit().putString("lat",String.valueOf(map.lat()))
            .putString("lon",String.valueOf(map.lon()))
            .putString("city","موقعي المحدد قرب Lagan").apply();
        Scheduler.schedule(this);
        Toast.makeText(this,"تم حفظ موقع العلامة. حدّث المواقيت والطقس في الصفحة الرئيسية.",Toast.LENGTH_LONG).show();
        finish();
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if(map!=null && map.hasFocus() && event.getAction()==KeyEvent.ACTION_DOWN){
            int code=event.getKeyCode();
            if(code==KeyEvent.KEYCODE_DPAD_UP){map.movePixels(0,-28);return true;}
            if(code==KeyEvent.KEYCODE_DPAD_DOWN){map.movePixels(0,28);return true;}
            if(code==KeyEvent.KEYCODE_DPAD_LEFT){map.movePixels(-28,0);return true;}
            if(code==KeyEvent.KEYCODE_DPAD_RIGHT){map.movePixels(28,0);return true;}
            if(code==KeyEvent.KEYCODE_DPAD_CENTER || code==KeyEvent.KEYCODE_ENTER){savePoint();return true;}
        }
        return super.dispatchKeyEvent(event);
    }
}
