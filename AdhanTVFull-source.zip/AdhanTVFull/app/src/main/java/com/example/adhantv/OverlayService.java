package com.example.adhantv;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class OverlayService extends Service {
    public static final String EXTRA_DELAY="delay";
    public static final String EXTRA_PRAYER="prayer";
    public static final String EXTRA_TIME="prayerTime";
    public static final String EXTRA_DEMO="demo";
    private static final String CHANNEL="adhan_alarm_v2";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private FrameLayout overlay;
    private Runnable pending, expiry;
    private MediaPlayer player;
    private AudioManager audio;
    private AudioFocusRequest focusRequest;
    private boolean focusHeld=false;
    private final AudioManager.OnAudioFocusChangeListener focusListener=change -> {
        // The system controls media fade/pause. Never change the device's master volume.
    };

    @Override public void onCreate() {
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        audio=(AudioManager)getSystemService(AUDIO_SERVICE);
        NotificationChannel nc=new NotificationChannel(CHANNEL,"Adhan TV prayer alert",NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(nc);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        try {
            PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("Adhan TV")
                .setContentText("تنبيه الصلاة").setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(open).setOngoing(true).build();
            if(Build.VERSION.SDK_INT>=34) startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(7,n);
        } catch(Exception e) { stopSelf(); return START_NOT_STICKY; }
        reset();
        int delay=intent==null?0:intent.getIntExtra(EXTRA_DELAY,0);
        String prayer=intent==null?"Dhuhr":intent.getStringExtra(EXTRA_PRAYER);
        String time=intent==null?"":intent.getStringExtra(EXTRA_TIME);
        boolean demo=intent!=null && intent.getBooleanExtra(EXTRA_DEMO,false);
        if(prayer==null || prayer.isEmpty()) prayer="Dhuhr";
        final String p=prayer, t=time==null?"":time;
        delay=Math.min(180,Math.max(0,delay));
        pending=()->show(p,t,demo);
        handler.postDelayed(pending,delay*1000L);
        expiry=this::close;
        handler.postDelayed(expiry,delay*1000L+4*60*1000L);
        return START_NOT_STICKY;
    }
    private void show(String prayer,String time,boolean demo) {
        if(!Settings.canDrawOverlays(this)) { close(); return; }
        try {
            overlay=new FrameLayout(this) {
                @Override public boolean dispatchKeyEvent(KeyEvent ev) {
                    int code=ev.getKeyCode();
                    if(code==KeyEvent.KEYCODE_DPAD_CENTER || code==KeyEvent.KEYCODE_ENTER ||
                       code==KeyEvent.KEYCODE_NUMPAD_ENTER || code==KeyEvent.KEYCODE_BACK) {
                        if(ev.getAction()==KeyEvent.ACTION_UP) close();
                        return true;
                    }
                    return super.dispatchKeyEvent(ev);
                }
            };
            overlay.setFocusable(true); overlay.setFocusableInTouchMode(true);
            overlay.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            overlay.setBackgroundColor(0xF20A1C2B);
            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);
            card.setPadding(dp(24),dp(24),dp(24),dp(24));
            GradientDrawable shape=new GradientDrawable();shape.setColor(0xFF142E3D);
            shape.setCornerRadius(dp(28)); shape.setStroke(dp(2),0xFFEAC77F);card.setBackground(shape);
            text(card,"☾",48,0xFFEAC77F,true);
            text(card,demo?"تجربة تنبيه الصلاة":"حان الآن وقت صلاة "+Config.arabic(prayer),32,Color.WHITE,true);
            if(demo) text(card,"الصلاة التالية: "+Config.arabic(prayer),24,0xFFEAC77F,true);
            else text(card,"حيّ على الصلاة",25,0xFFEAC77F,false);
            String shown=time;
            try { shown=LocalTime.parse(time).format(DateTimeFormatter.ofPattern("HH:mm",Locale.US)); }
            catch(Exception ignored) { }
            if(!shown.isEmpty()) text(card,"الموعد: "+shown,27,Color.WHITE,true);
            text(card,Config.city(this)+" • "+Config.methodName(this),17,0xFFCCDADE,false);
            text(card,WeatherRepository.display(this),19,0xFFEAC77F,false);
            double q=Qibla.bearing(Config.lat(this),Config.lon(this));
            text(card,String.format(Locale.US,"القبلة: %.0f° من الشمال الحقيقي (%s)",q,Qibla.direction(q)),17,0xFFCCDADE,false);
            text(card,demo?"هذا اختبار الآن وليس موعد الصلاة الحقيقي":"تذكير بأداء الصلاة",17,0xFFCCDADE,false);
            Button ok=new Button(this);
            ok.setText("OK — العودة للمشاهدة والصوت"); ok.setAllCaps(false);
            ok.setTextSize(19);ok.setTextColor(0xFF122D3A);
            GradientDrawable buttonBg=new GradientDrawable();buttonBg.setColor(0xFFEAC77F);
            buttonBg.setCornerRadius(dp(12));ok.setBackground(buttonBg);
            ok.setOnClickListener(v->close());
            LinearLayout.LayoutParams btn=new LinearLayout.LayoutParams(dp(390),dp(58));
            btn.topMargin=dp(18);card.addView(ok,btn);
            FrameLayout.LayoutParams center=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
            center.leftMargin=dp(55);center.rightMargin=dp(55);overlay.addView(card,center);
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.CENTER;lp.setTitle("Adhan TV — "+prayer);
            wm.addView(overlay,lp);overlay.requestFocus();ok.requestFocus();
            takeAudioFocus();
            if(Config.playSound(this)) playSound();
        } catch(Exception e) {
            Toast.makeText(this,"فشل تنبيه الأذان: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();
            close();
        }
    }
    private void takeAudioFocus() {
        try {
            AudioAttributes attrs=new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
            // Transient focus requests that the playing app pause or be silenced temporarily.
            // Never change the TV master volume, which could also silence the adhan.
            focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs).setOnAudioFocusChangeListener(focusListener).build();
            focusHeld=audio.requestAudioFocus(focusRequest)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        } catch(Exception ignored) { focusHeld=false; }
    }
    private void playSound() {
        try {
            int id=getResources().getIdentifier("adhan","raw",getPackageName());
            if(id==0) id=R.raw.fallback;
            player=MediaPlayer.create(this,id);
            if(player==null) return;
            player.setOnCompletionListener(mp->{
                try { mp.stop(); } catch(Exception ignored) { }
            });
            player.start();
        } catch(Exception ignored) { }
    }
    private void text(LinearLayout p,String s,int size,int color,boolean bold) {
        TextView tv=new TextView(this);tv.setText(s);tv.setTextSize(size);tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);tv.setPadding(dp(5),dp(4),dp(5),dp(4));
        if(bold) tv.setTypeface(null,Typeface.BOLD);
        p.addView(tv,new LinearLayout.LayoutParams(-1,-2));
    }
    private void reset() { if(pending!=null)handler.removeCallbacks(pending); if(expiry!=null)handler.removeCallbacks(expiry);
        pending=null;expiry=null;releaseMedia();remove(); }
    private void releaseMedia() {
        if(player!=null) { try {player.release();}catch(Exception ignored){} player=null; }
        if(focusHeld && focusRequest!=null) {
            try { audio.abandonAudioFocusRequest(focusRequest); } catch(Exception ignored) { }
        }
        focusHeld=false;focusRequest=null;
    }
    private void remove() { if(overlay!=null) {
        try { wm.removeViewImmediate(overlay); } catch(Exception ignored) {} overlay=null; }
    }
    private void close() { reset();stopSelf(); }
    @Override public void onDestroy() { reset();super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
    private int dp(float d) { return Math.round(d*getResources().getDisplayMetrics().density); }
}
