package com.example.adhantv;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int GOLD=0xFFEAC77F,WHITE=0xFFF3F7FA,BLUE=0xFF204E62;
    private LinearLayout content;
    private TextView state, prayerTimes, countdown, weatherText, qiblaText;
    private final Handler refreshHandler = new Handler(Looper.getMainLooper());
    private final Runnable refreshClock=new Runnable(){@Override public void run(){refreshScreen();refreshHandler.postDelayed(this,30000);}};
    private EditText city,latitude,longitude;
    private String lastLocation="";
    private volatile boolean updating=false;
    private static final String[] CITIES={"Lagan, Sverige","Växjö, Sverige","Göteborg, Sverige","Stockholm, Sverige","Malmö, Sverige"};
    private static final double[] LATS={56.91505,56.8790,57.7089,59.3293,55.6050};
    private static final double[] LONS={13.99102,14.8059,11.9746,18.0686,13.0038};

    @Override public void onCreate(Bundle saved) {super.onCreate(saved);draw();
        if(PrayerRepository.day(this,LocalDate.now(Config.zoneId(this))).isEmpty()) updateTimes(false);
        else Scheduler.schedule(this);
        if(!WeatherRepository.isFresh(this))updateWeather(false);
    }
    @Override protected void onResume() {super.onResume();
        String currentLocation=String.format(Locale.US,"%.5f,%.5f",Config.lat(this),Config.lon(this));
        if(!currentLocation.equals(lastLocation))draw();
        refreshHandler.removeCallbacks(refreshClock);refreshHandler.post(refreshClock);
        if(state!=null && !WeatherRepository.isFresh(this))updateWeather(false);
        if(PrayerRepository.day(this,LocalDate.now(Config.zoneId(this))).isEmpty())updateTimes(false);
    }
    @Override protected void onPause(){refreshHandler.removeCallbacks(refreshClock);super.onPause();}
    private void draw() {
        lastLocation=String.format(Locale.US,"%.5f,%.5f",Config.lat(this),Config.lon(this));
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(0xFF0A1A28);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content.setPadding(dp(38),dp(20),dp(38),dp(20));sc.addView(content);
        setContentView(sc);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        label("☾  أذان التلفزيون",32,GOLD,true);
        label("مواقيت الصلاة والتنبيه أثناء المشاهدة • Thomson Android TV",17,WHITE,false);
        state=label("",18,GOLD,true);
        countdown=label("",20,WHITE,true);
        prayerTimes=label("",19,WHITE,false);
        label("الطقس والقبلة",23,GOLD,true);
        weatherText=label("",21,WHITE,true);
        qiblaText=label("",19,GOLD,true);
        button("خريطة القبلة وتحديد البيت بالريموت",0xFF126F75,()->startActivity(new Intent(this,MapActivity.class)));
        button("تحديث الطقس الآن",BLUE,()->updateWeather(true));

        label("المدينة وموقعك",23,GOLD,true);
        label("مبدئياً: Lagan في السويد. عدّلها إن كنت في مدينة أخرى.",15,0xFFB5CBD6,false);
        city=field("اسم المدينة",Config.city(this));
        latitude=field("خط العرض",String.format(Locale.US,"%.5f",Config.lat(this)));
        longitude=field("خط الطول",String.format(Locale.US,"%.5f",Config.lon(this)));
        button("اختيار مدينة سويدية (يتنقل بين خمس مدن)",BLUE,()->cycleCity());
        button("حفظ المدينة والإحداثيات",BLUE,()->saveLocation());
        label("طريقة الحساب التلقائية: رابطة العالم الإسلامي (MWL)، مع ضبط خطوط العرض الشمالية. لا تحتاج تختار شيئاً.",15,0xFFB5CBD6,false);

        label("المنبّهات والتجربة",23,GOLD,true);
        button(Config.enabled(this)?"✓ الأذان التلقائي: مفعّل (اضغط للإيقاف)":"الأذان التلقائي: متوقف (اضغط للتفعيل)",0xFF1C6070,()->{
            Config.prefs(this).edit().putBoolean("enabled",!Config.enabled(this)).apply();Scheduler.schedule(this);draw();
        });
        button(Config.playSound(this)?"✓ صوت الأذان: مفعّل":"صوت الأذان: متوقف",BLUE,()->{
            Config.prefs(this).edit().putBoolean("playSound",!Config.playSound(this)).apply();draw();
        });
        button("إذن العرض فوق التطبيقات",BLUE,this::openOverlaySettings);
        button("إذن المنبّهات الدقيقة",BLUE,this::openExactSettings);
        button("تحديث جميع البيانات: المواقيت والطقس",0xFF126F75,()->{updateTimes(true);updateWeather(true);});
        button("اختبار واقعي الآن (الصلاة التالية + الصوت)",0xFF126F75,()->test(0));
        button("اختبار واقعي بعد ٦٠ ثانية (افتح Netflix)",0xFF126F75,()->test(60));
        label("أغلق الشاشة بزر OK أو Back. سيحاول النظام إسكات صوت الفيلم مؤقتاً وإعادته بعد إغلاق الشاشة؛ النتيجة تعتمد على Netflix والجهاز.",15,0xFFB5CBD6,false);
        label("المصدر: AlAdhan API • مواقيت حسابية قد تختلف عن مسجدك، خاصة الفجر والعشاء في السويد. تأكد من طريقة الحساب قبل الاعتماد عليها.",14,GOLD,false);
        refreshScreen();
    }
    private void refreshScreen() {
        if(state==null)return;
        boolean overlay=Settings.canDrawOverlays(this);
        boolean exact=Scheduler.precise(this);
        state.setText((overlay?"✓":"⚠")+" العرض فوق التطبيقات  |  "+(exact?"✓":"⚠")+" منبّهات دقيقة  |  "+(Config.enabled(this)?"تنبيهات مفعّلة":"تنبيهات متوقفة"));
        LocalDate date=LocalDate.now(Config.zoneId(this));
        List<PrayerRepository.Entry> times=PrayerRepository.day(this,date);
        StringBuilder str=new StringBuilder("مواقيت اليوم "+date+" • "+Config.city(this)+"\n");
        if(times.isEmpty()) str.append("لا توجد بيانات فعلية بعد؛ اضغط تحديث المواقيت.");
        else for(PrayerRepository.Entry e:times) str.append(e.arabic).append("  ").append(e.time).append("     ");
        prayerTimes.setText(str.toString());
        if(weatherText!=null) weatherText.setText(WeatherRepository.display(this)+" • Open-Meteo");
        if(qiblaText!=null){
            double bearing=Qibla.bearing(Config.lat(this),Config.lon(this));
            qiblaText.setText(String.format(Locale.US,"اتجاه القبلة: %.1f° من الشمال الحقيقي • %s",bearing,Qibla.direction(bearing)));
        }
        PrayerRepository.Entry next=PrayerRepository.next(this,System.currentTimeMillis());
        if(next==null) countdown.setText("الصلاة القادمة: البيانات غير متوفرة");
        else {
            long seconds=Math.max(0,(next.millis-System.currentTimeMillis())/1000);
            countdown.setText(String.format(Locale.US,"الصلاة القادمة: %s • %s • بعد %02d:%02d",
                next.arabic,next.time,seconds/3600,(seconds%3600)/60));
        }
    }
    private void updateTimes(boolean notify) {
        if(updating)return;
        updating=true;
        if(state!=null) state.setText("جارٍ جلب المواقيت الحقيقية...");
        new Thread(()->{
            String result=PrayerRepository.refreshTodayAndTomorrow(getApplicationContext());
            runOnUiThread(()->{
                updating=false;refreshScreen();
                if(notify || result.startsWith("فشل"))Toast.makeText(this,result,Toast.LENGTH_LONG).show();
            });
        },"adhan-tv-fetch").start();
    }
    private void updateWeather(boolean force) {
        if(weatherText!=null) weatherText.setText("جارٍ جلب الطقس من Open-Meteo...");
        new Thread(()->{
            String error=null;
            try{WeatherRepository.refresh(getApplicationContext(),force);}catch(Exception e){error=e.getMessage();}
            final String problem=error;
            runOnUiThread(()->{
                refreshScreen();
                if(problem!=null && force)Toast.makeText(this,"تعذّر جلب الطقس: "+problem,Toast.LENGTH_LONG).show();
            });
        },"adhan-weather").start();
    }
    private void test(int delay) {
        if(!Settings.canDrawOverlays(this)) {openOverlaySettings();Toast.makeText(this,"فعّل العرض فوق التطبيقات",Toast.LENGTH_LONG).show();return;}
        PrayerRepository.Entry next=PrayerRepository.next(this,System.currentTimeMillis());
        if(next==null) {Toast.makeText(this,"حدّث المواقيت أولاً وانتظر نجاح الاتصال",Toast.LENGTH_LONG).show();updateTimes(true);return;}
        Intent service=new Intent(this,OverlayService.class);
        service.putExtra(OverlayService.EXTRA_PRAYER,next.key);
        service.putExtra(OverlayService.EXTRA_TIME,next.time.toString());
        service.putExtra(OverlayService.EXTRA_DEMO,true);
        service.putExtra(OverlayService.EXTRA_DELAY,delay);
        try {
            if(Build.VERSION.SDK_INT>=26)startForegroundService(service);
            else startService(service);
            if(delay>0){
                Toast.makeText(this,"الاختبار بعد "+delay+" ثانية",Toast.LENGTH_SHORT).show();
                Intent home=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
                home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(home);
            }
        }catch(Exception e){Toast.makeText(this,"تعذر بدء الاختبار: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void saveLocation(){
        try {
            double la=Double.parseDouble(latitude.getText().toString().trim());
            double lo=Double.parseDouble(longitude.getText().toString().trim());
            if(la<-90||la>90||lo<-180||lo>180)throw new Exception("الإحداثيات غير صالحة");
            String name=city.getText().toString().trim();
            if(name.isEmpty())name="موقع مخصص";
            Config.prefs(this).edit().putString("city",name)
                .putString("lat",String.valueOf(la)).putString("lon",String.valueOf(lo)).apply();
            Scheduler.schedule(this);draw();updateTimes(true);updateWeather(true);
        }catch(Exception e){Toast.makeText(this,"تحقق من الإحداثيات: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void cycleCity(){
        String current=city.getText().toString().trim();int i=-1;
        for(int n=0;n<CITIES.length;n++)if(CITIES[n].equals(current)){i=n;break;}
        i=(i+1)%CITIES.length;
        city.setText(CITIES[i]);latitude.setText(String.format(Locale.US,"%.5f",LATS[i]));
        longitude.setText(String.format(Locale.US,"%.5f",LONS[i]));
        Toast.makeText(this,"المدينة: "+CITIES[i]+". اضغط حفظ المدينة.",Toast.LENGTH_SHORT).show();
    }
    private void cycleMethod() {
        int[] methods={3,4,13,5};int old=Config.method(this),index=0;
        for(int n=0;n<methods.length;n++)if(methods[n]==old)index=n;
        Config.prefs(this).edit().putInt("method",methods[(index+1)%methods.length]).apply();
        draw();updateTimes(true);
    }
    private void cycleHighLat(){
        int x=Config.highLat(this);Config.prefs(this).edit().putInt("highLat",x==3?1:(x==1?2:3)).apply();
        draw();updateTimes(true);
    }
    private String highLatName(){
        return Config.highLat(this)==3?"نسبة الزاوية":(Config.highLat(this)==1?"نصف الليل":"سبع الليل");
    }
    private void openExactSettings(){
        if(Scheduler.precise(this)){Toast.makeText(this,"المنبّهات الدقيقة مفعّلة",Toast.LENGTH_SHORT).show();return;}
        try {
            Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:"+getPackageName()));startActivity(i);
        }catch(Exception e){
            Toast.makeText(this,"افتح إعدادات التطبيق وابحث عن Alarms & reminders",Toast.LENGTH_LONG).show();
        }
    }
    private void openOverlaySettings(){
        try {startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:"+getPackageName())));}
        catch(Exception e){startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:"+getPackageName())));}
    }
    private TextView label(String s,int sp,int color,boolean bold){
        TextView tv=new TextView(this);tv.setText(s);tv.setTextColor(color);tv.setTextSize(sp);
        tv.setGravity(Gravity.CENTER);tv.setPadding(dp(10),dp(5),dp(10),dp(7));
        if(bold)tv.setTypeface(null,Typeface.BOLD);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(7);
        content.addView(tv,p);return tv;
    }
    private EditText field(String hint,String value){
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(value);
        e.setTextColor(WHITE);e.setHintTextColor(0xFF94B7C8);e.setTextSize(17);
        e.setBackgroundColor(0xFF173849);e.setPadding(dp(16),dp(9),dp(16),dp(9));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Math.min(getResources().getDisplayMetrics().widthPixels-dp(90),dp(680)),dp(53));
        p.bottomMargin=dp(9);content.addView(e,p);return e;
    }
    private Button button(String s,int bg,Runnable action){
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(17);
        b.setFocusable(true);b.setTextColor(WHITE);b.setBackground(shape(bg,GOLD));
        b.setOnFocusChangeListener((v,focused)->b.setBackground(shape(focused?0xFF396E86:bg,focused?WHITE:GOLD)));
        b.setOnClickListener(v->action.run());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(Math.min(getResources().getDisplayMetrics().widthPixels-dp(90),dp(700)),dp(58));
        p.bottomMargin=dp(9);content.addView(b,p);return b;
    }
    private GradientDrawable shape(int fill,int stroke){
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(12));d.setStroke(dp(1),stroke);return d;
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
