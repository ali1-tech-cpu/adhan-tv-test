package com.example.adhantv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/** Offline-friendly, read-only dashboard shared by system DreamService and a manual preview.
 * Uses cached prayer times/weather. Network refreshing happens off the UI thread. */
public final class DreamBoard extends FrameLayout {
    private static final int GOLD=0xFFEAC77F;
    private static final int WHITE=0xFFF0F7FA;
    private static final int MUTED=0xFFB7CFD8;
    private final Context app;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView time,date,times,next,weather,city;
    private QiblaCompass compass;
    private LinearLayout board;
    private boolean active=false;
    private boolean fetching=false;
    private long nextCheck=0;
    private final Runnable ticker=new Runnable(){@Override public void run(){
        if(!active)return;
        updateScreen();
        handler.postDelayed(this,1000);
    }};

    public DreamBoard(Context context) {
        super(context);
        app=context.getApplicationContext();
        setBackgroundColor(0xFF050F19);
        board=new LinearLayout(context);board.setOrientation(LinearLayout.VERTICAL);
        board.setGravity(Gravity.CENTER);board.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        board.setPadding(dp(50),dp(32),dp(50),dp(32));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xFF112D3A,0xFF071925,0xFF183039});
        bg.setCornerRadius(dp(35));bg.setStroke(dp(1),0xFF466070);board.setBackground(bg);
        addLabel("☾  أذان التلفزيون",26,GOLD,true);
        time=addLabel("--:--:--",75,WHITE,true);
        date=addLabel("",23,MUTED,false);
        city=addLabel("",18,GOLD,false);
        addSpacer(18);
        times=addLabel("جارٍ قراءة مواقيت الصلاة...",24,WHITE,true);
        addSpacer(15);
        next=addLabel("",30,GOLD,true);
        addSpacer(15);
        LinearLayout bottom=new LinearLayout(context);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        weather=new TextView(context);weather.setTextColor(WHITE);weather.setTextSize(21);
        weather.setGravity(Gravity.CENTER);
        bottom.addView(weather,new LinearLayout.LayoutParams(0,-2,2));
        compass=new QiblaCompass(context);
        bottom.addView(compass,new LinearLayout.LayoutParams(dp(118),dp(118)));
        board.addView(bottom,new LinearLayout.LayoutParams(-1,-2));
        addLabel("مواقيت حسابية • القبلة بالنسبة إلى الشمال الحقيقي ↑",14,MUTED,false);
        FrameLayout.LayoutParams card=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        card.setMargins(dp(70),dp(30),dp(70),dp(30));addView(board,card);
        updateScreen();
    }
    private void addSpacer(int h){View v=new View(getContext());board.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private TextView addLabel(String title,int size,int color,boolean bold){
        TextView label=new TextView(getContext());label.setText(title);label.setTextSize(size);
        label.setTextColor(color);label.setGravity(Gravity.CENTER);
        label.setPadding(dp(4),dp(3),dp(4),dp(3));
        if(bold)label.setTypeface(null,Typeface.BOLD);
        board.addView(label,new LinearLayout.LayoutParams(-1,-2));return label;
    }
    public void start(){
        if(active)return;
        active=true;
        handler.removeCallbacks(ticker);handler.post(ticker);
        loadIfNeeded();
    }
    public void stop(){ active=false;handler.removeCallbacks(ticker); }
    private void loadIfNeeded(){
        if(fetching)return;
        long now=System.currentTimeMillis();
        if(now<nextCheck)return;
        nextCheck=now+5*60*1000L;
        boolean missing=PrayerRepository.day(app,LocalDate.now(Config.zoneId(app))).isEmpty();
        if(!missing && WeatherRepository.isFresh(app))return;
        fetching=true;
        new Thread(()->{
            try{
                if(missing)PrayerRepository.refreshTodayAndTomorrow(app);
                if(!WeatherRepository.isFresh(app)) WeatherRepository.refresh(app,false);
            }catch(Exception ignored){}
            finally{fetching=false;handler.post(()->{if(active)updateScreen();});}
        },"adhan-dream-data").start();
    }
    private void updateScreen(){
        ZonedDateTime clock=ZonedDateTime.now(Config.zoneId(app));
        time.setText(clock.format(DateTimeFormatter.ofPattern("HH:mm:ss",Locale.US)));
        date.setText(clock.format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy",new Locale("ar"))));
        city.setText(Config.city(app));
        List<PrayerRepository.Entry> entries=PrayerRepository.day(app,clock.toLocalDate());
        if(entries.isEmpty())times.setText("مواقيت الصلاة غير متوفرة — افتح التطبيق وحدّث الأوقات");
        else{
            StringBuilder b=new StringBuilder();
            for(PrayerRepository.Entry e:entries){
                if(b.length()>0)b.append("     •     ");
                b.append(e.arabic).append("  ").append(e.time);
            }
            times.setText(b.toString());
        }
        PrayerRepository.Entry n=PrayerRepository.next(app,System.currentTimeMillis());
        if(n==null)next.setText("الصلاة القادمة: غير متوفرة");
        else{
            long sec=Math.max(0,(n.millis-System.currentTimeMillis())/1000);
            next.setText(String.format(Locale.US,"الصلاة القادمة: %s   بعد  %02d:%02d:%02d",
                n.arabic,sec/3600,(sec%3600)/60,sec%60));
        }
        weather.setText(WeatherRepository.display(app));
        compass.setHeading(Qibla.bearing(Config.lat(app),Config.lon(app)));
        // Move by a few pixels to avoid displaying exactly the same pixels throughout idle time.
        long minute=System.currentTimeMillis()/60000;
        board.setTranslationX(dp((int)(12*Math.sin(minute/5.0))));
        board.setTranslationY(dp((int)(8*Math.cos(minute/7.0))));
        if(minute%5==0 && System.currentTimeMillis()>=nextCheck)loadIfNeeded();
    }
    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private static final class QiblaCompass extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private double heading;
        QiblaCompass(Context c){super(c);}
        void setHeading(double heading){this.heading=heading;invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);
            float midX=getWidth()/2f,midY=getHeight()/2f,rad=Math.min(midX,midY)*.65f;
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);paint.setColor(0xFFA9C4D2);
            c.drawCircle(midX,midY,rad,paint);
            paint.setStyle(Paint.Style.FILL);paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(20);c.drawText("N",midX,midY-rad-8,paint);
            double angle=Math.toRadians(heading-90);
            float toX=midX+(float)Math.cos(angle)*rad*.88f;
            float toY=midY+(float)Math.sin(angle)*rad*.88f;
            paint.setColor(GOLD);paint.setStrokeWidth(7);paint.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(midX,midY,toX,toY,paint);
            Path p=new Path();p.moveTo(toX,toY);
            p.lineTo(toX-(float)Math.cos(angle-0.4)*18,toY-(float)Math.sin(angle-0.4)*18);
            p.lineTo(toX-(float)Math.cos(angle+0.4)*18,toY-(float)Math.sin(angle+0.4)*18);
            p.close();c.drawPath(p,paint);
            paint.setTextSize(16);paint.setColor(WHITE);
            c.drawText(String.format(Locale.US,"%.0f°",heading),midX,midY+rad+20,paint);
        }
    }
}
