package com.example.adhantv;

import android.content.Context;
import android.content.SharedPreferences;
import java.time.ZoneId;
import java.util.Locale;

public final class Config {
    private Config() {}
    public static SharedPreferences prefs(Context c) { return c.getSharedPreferences("settings_v2", Context.MODE_PRIVATE); }
    public static final String[] PRAYERS = { "Fajr", "Dhuhr", "Asr", "Maghrib", "Isha" };
    public static final String[] AR = { "الفجر", "الظهر", "العصر", "المغرب", "العشاء" };
    public static String arabic(String en) {
        for (int i=0;i<PRAYERS.length;i++) if (PRAYERS[i].equals(en)) return AR[i];
        return en;
    }
    public static String city(Context c) { return prefs(c).getString("city", "Lagan, Sverige"); }
    public static double lat(Context c) { return getDouble(c, "lat", 56.91505); }
    public static double lon(Context c) { return getDouble(c, "lon", 13.99102); }
    public static double getDouble(Context c,String key,double fallback) {
        try { return Double.parseDouble(prefs(c).getString(key, String.valueOf(fallback))); }
        catch (Exception ex) { return fallback; }
    }
    public static String zone(Context c) { return prefs(c).getString("zone", "Europe/Stockholm"); }
    public static ZoneId zoneId(Context c) {
        try { return ZoneId.of(zone(c)); } catch (Exception ex) { return ZoneId.of("Europe/Stockholm"); }
    }
    public static int method(Context c) { return prefs(c).getInt("method",3); }
    public static int highLat(Context c) { return prefs(c).getInt("highLat",3); }
    public static int school(Context c) { return prefs(c).getInt("school",0); }
    public static boolean enabled(Context c) { return prefs(c).getBoolean("enabled",true); }
    public static int adhanVolume(Context c) {
        return Math.max(0, Math.min(100, prefs(c).getInt("adhan_volume",35)));
    }
    public static boolean playSound(Context c) { return prefs(c).getBoolean("playSound",true); }
    public static String methodName(Context c) {
        switch(method(c)) {
            case 3: return "رابطة العالم الإسلامي MWL";
            case 4: return "أم القرى";
            case 13: return "ديانت التركية";
            case 5: return "الهيئة المصرية";
            default: return "طريقة " + method(c);
        }
    }
    public static String cacheKey(Context c, String day) {
        String sig=String.format(Locale.US,"%.5f_%.5f_%d_%d_%d_%s",
                lat(c),lon(c),method(c),highLat(c),school(c),zone(c));
        return "times_"+sig+"_"+day;
    }
}
