package com.example.adhantv;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Open-Meteo forecast; free non-commercial endpoint; no key and no GPS permission. */
public final class WeatherRepository {
    private WeatherRepository() {}
    private static final long MAX_AGE_MS = 45L * 60 * 1000;
    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences("weather_cache", Context.MODE_PRIVATE);
    }
    private static String key(Context c) {
        return String.format(Locale.US,"%.5f_%.5f",Config.lat(c),Config.lon(c));
    }
    public static boolean isFresh(Context context) {
        SharedPreferences p=prefs(context);
        return key(context).equals(p.getString("position", ""))
            && System.currentTimeMillis()-p.getLong("updated",0)<MAX_AGE_MS;
    }
    public static String display(Context c) {
        SharedPreferences p=prefs(c);
        if (!key(c).equals(p.getString("position", "")) || !p.contains("temp"))
            return "الطقس: غير متوفر — حدّث البيانات";
        double temp=Double.longBitsToDouble(p.getLong("temp",Double.doubleToLongBits(0)));
        int code=p.getInt("code",-1);
        long age=(System.currentTimeMillis()-p.getLong("updated",0))/60000;
        return String.format(Locale.US,"الطقس: %.0f°م • %s%s",temp,description(code),age>=120?" (بيانات قديمة)":"");
    }
    public static String description(int code) {
        if(code==0) return "صحو";
        if(code==1||code==2) return "غائم جزئياً";
        if(code==3) return "غائم";
        if(code==45||code==48) return "ضباب";
        if(code>=51&&code<=57) return "رذاذ";
        if(code>=61&&code<=67) return "مطر";
        if(code>=71&&code<=77) return "ثلج";
        if(code>=80&&code<=82) return "زخات مطر";
        if(code>=85&&code<=86) return "زخات ثلج";
        if(code>=95) return "عواصف رعدية";
        return "حالة جوية غير معروفة";
    }
    public static void refresh(Context context, boolean force) throws Exception {
        if(!force && isFresh(context))return;
        // Call on a background thread only.
        String url=String.format(Locale.US,
            "https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,weather_code&timezone=Europe%%2FStockholm",
            Config.lat(context),Config.lon(context));
        HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();
        connection.setConnectTimeout(7000);connection.setReadTimeout(7000);
        connection.setRequestProperty("Accept","application/json");
        try {
            if(connection.getResponseCode()!=200)throw new Exception("Weather HTTP "+connection.getResponseCode());
            StringBuilder body=new StringBuilder();
            try(BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream(),StandardCharsets.UTF_8))){
                String line;while((line=br.readLine())!=null)body.append(line);
            }
            JSONObject now=new JSONObject(body.toString()).getJSONObject("current");
            double temp=now.getDouble("temperature_2m"); int code=now.getInt("weather_code");
            prefs(context).edit().putString("position",key(context))
                .putLong("temp",Double.doubleToLongBits(temp))
                .putInt("code",code).putLong("updated",System.currentTimeMillis()).apply();
        }finally{connection.disconnect();}
    }
}
