# Adhan TV Test
A minimal native Android TV **overlay feasibility test**, not a full prayer-times app. Uses no network, no advertising, no third-party libraries.

Open in Android Studio (AGP 8.6.1, compileSdk 35, JDK 17), sync, select `Build APK(s)`. Output: `app/build/outputs/apk/debug/app-debug.apk`.

- Install on Android TV/Google TV and enable its `Display over other apps` permission.
- Use the immediate overlay test, then the 60-second test; it returns to HOME so you can open Netflix or YouTube via the Thomson box.
- On-screen OK/Back closes overlay. Auto-dismisses in 90 seconds.
- No guarantee of overlays atop protected video apps; playback is neither paused nor controlled.
- Test times and prayer labels are **illustrative only**; this version has no scheduling or adhan audio.
