package com.example.adhantvtest;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView permissionStatus;
    private Button permissionButton;
    private LinearLayout content;
    private static final int GOLD = Color.rgb(232, 194, 121);
    private static final int WHITE = Color.rgb(243, 247, 250);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(10, 26, 40));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(36), dp(22), dp(36), dp(22));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(content, new ScrollView.LayoutParams(-1, -1));
        setContentView(scroll);

        title("اختبار تنبيه الأذان", 30, GOLD, true);
        title("نسخة تجريبية لجهاز Thomson Android TV 14", 19, WHITE, false);
        title("نختبر ظهور التنبيه فوق Netflix وYouTube. لا توجد مواقيت صلاة فعلية في هذه النسخة.", 16, 0xFFB8CBD5, false);
        permissionStatus = title("", 19, GOLD, true);
        permissionButton = button("١ — السماح بالعرض فوق التطبيقات", 0xFF24546D);
        permissionButton.setOnClickListener(v -> openOverlaySettings());

        Button now = button("٢ — إظهار تنبيه تجريبي الآن", 0xFF126E7D);
        now.setOnClickListener(v -> startTest(0));
        Button delay15 = button("٣ — اختبار بعد ١٥ ثانية", 0xFF244D64);
        delay15.setOnClickListener(v -> startTest(15));
        Button delay60 = button("٤ — اختبار بعد ٦٠ ثانية (افتح Netflix)", 0xFF244D64);
        delay60.setOnClickListener(v -> startTest(60));

        title("بعد الضغط على اختبار ٦٠ ثانية سترجع للشاشة الرئيسية. افتح Netflix أو YouTube خلال الدقيقة. عندما يظهر التنبيه اضغط OK أو رجوع لإخفائه.", 16, 0xFFB8CBD5, false);
        title("ملاحظة: بعض تطبيقات الفيديو قد تمنع عرض النوافذ فوقها. الاختبار لا يوقف الفيلم ولا يضمن إيقافه مؤقتاً.", 15, 0xFFE9C282, false);
        refreshPermission();
    }

    @Override protected void onResume() {
        super.onResume();
        if (permissionStatus != null) refreshPermission();
    }

    private void refreshPermission() {
        boolean has = Settings.canDrawOverlays(this);
        permissionStatus.setText(has ? "✓ صلاحية العرض فوق التطبيقات: مفعّلة" : "! صلاحية العرض فوق التطبيقات: غير مفعّلة");
        permissionStatus.setTextColor(has ? 0xFF91DDC0 : GOLD);
        permissionButton.setText(has ? "إعدادات صلاحية العرض (مفعّلة)" : "١ — فعّل صلاحية العرض فوق التطبيقات");
    }

    private void openOverlaySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            } catch (Exception ignored) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
            }
        }
    }

    private void startTest(int seconds) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن العرض فوق التطبيقات أولاً", Toast.LENGTH_LONG).show();
            openOverlaySettings();
            return;
        }
        Intent service = new Intent(this, OverlayTestService.class);
        service.putExtra(OverlayTestService.EXTRA_DELAY_SECONDS, seconds);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
            if (seconds > 0) {
                Toast.makeText(this, "التنبيه سيظهر بعد " + seconds + " ثانية", Toast.LENGTH_LONG).show();
                Intent home = new Intent(Intent.ACTION_MAIN);
                home.addCategory(Intent.CATEGORY_HOME);
                home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(home);
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر تشغيل الاختبار: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    private TextView title(String str, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(str);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), dp(5), dp(12), dp(8));
        if (bold) tv.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(7);
        content.addView(tv, lp);
        return tv;
    }

    private Button button(String label, int color) {
        Button btn = new Button(this);
        btn.setAllCaps(false);
        btn.setText(label);
        btn.setTextSize(18);
        btn.setTextColor(WHITE);
        btn.setFocusable(true);
        btn.setBackground(shape(color, 0xFF8EB1BF));
        btn.setOnFocusChangeListener((view, focused) -> {
            btn.setBackground(shape(focused ? 0xFF366C88 : color, focused ? GOLD : 0xFF8EB1BF));
            btn.setScaleX(focused ? 1.02f : 1.0f);
            btn.setScaleY(focused ? 1.02f : 1.0f);
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            Math.min(getResources().getDisplayMetrics().widthPixels - dp(90), dp(650)), dp(62));
        lp.bottomMargin = dp(12);
        content.addView(btn, lp);
        return btn;
    }

    private GradientDrawable shape(int fill, int stroke) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(2), stroke);
        return bg;
    }

    private int dp(float dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
