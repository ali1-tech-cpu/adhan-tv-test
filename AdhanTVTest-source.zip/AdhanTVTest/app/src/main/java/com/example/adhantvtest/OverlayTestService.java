package com.example.adhantvtest;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class OverlayTestService extends Service {
    public static final String EXTRA_DELAY_SECONDS = "delaySeconds";
    private static final String CHANNEL = "adhan_tv_test";
    private static final int NOTIFICATION_ID = 17;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private FrameLayout overlay;
    private Runnable pending;
    private Runnable expiry;

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Adhan TV test",
            NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Temporary manual overlay test for prayer reminders");
        nm.createNotificationChannel(ch);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Notification notification = createNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر بدء الخدمة: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }
        clearTimers();
        removeOverlay();
        int delay = intent == null ? 0 : intent.getIntExtra(EXTRA_DELAY_SECONDS, 0);
        delay = Math.max(0, Math.min(delay, 120));
        pending = this::showOverlay;
        handler.postDelayed(pending, delay * 1000L);
        // The test automatically stops even if a TV app blocks its window.
        expiry = this::closeAndStop;
        handler.postDelayed(expiry, delay * 1000L + 90000L);
        return START_NOT_STICKY;
    }

    private Notification createNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
            .setContentTitle("Adhan TV Test")
            .setContentText("اختبار تنبيه الأذان جارٍ")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pi)
            .setOngoing(true)
            .build();
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            closeAndStop();
            return;
        }
        try {
            overlay = new FrameLayout(this) {
                @Override public boolean dispatchKeyEvent(KeyEvent event) {
                    int key = event.getKeyCode();
                    if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER
                        || key == KeyEvent.KEYCODE_NUMPAD_ENTER || key == KeyEvent.KEYCODE_BACK) {
                        if (event.getAction() == KeyEvent.ACTION_UP) closeAndStop();
                        return true;
                    }
                    return super.dispatchKeyEvent(event);
                }
            };
            overlay.setFocusable(true);
            overlay.setFocusableInTouchMode(true);
            overlay.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            overlay.setBackgroundColor(0xF20A1C2B);
            buildOverlayContents(overlay);

            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
            p.gravity = Gravity.CENTER;
            p.setTitle("Adhan TV Test — prayer overlay");
            windowManager.addView(overlay, p);
            overlay.requestFocus();
        } catch (Exception e) {
            Toast.makeText(this, "لم تنجح النافذة: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            closeAndStop();
        }
    }

    private void buildOverlayContents(FrameLayout root) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF152E3E);
        bg.setCornerRadius(dp(28));
        bg.setStroke(dp(2), 0xFFD7B779);
        card.setBackground(bg);

        addText(card, "☾", 44, 0xFFEAC77F, true);
        addText(card, "حان وقت الصلاة", 33, Color.WHITE, true);
        addText(card, "اختبار تنبيه الأذان — الظهر", 22, 0xFFEAC77F, false);
        addText(card, new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()),
            46, Color.WHITE, true);
        addText(card, "هذه شاشة تجريبية، وليست موعد صلاة حقيقياً", 17, 0xFFC8D9E1, false);

        Button dismiss = new Button(this);
        dismiss.setText("OK — العودة للمشاهدة");
        dismiss.setTextSize(19);
        dismiss.setAllCaps(false);
        dismiss.setTextColor(0xFF102636);
        GradientDrawable buttonBg = new GradientDrawable();
        buttonBg.setColor(0xFFEAC77F);
        buttonBg.setCornerRadius(dp(12));
        dismiss.setBackground(buttonBg);
        dismiss.setOnClickListener(v -> closeAndStop());
        LinearLayout.LayoutParams btn = new LinearLayout.LayoutParams(dp(330), dp(56));
        btn.topMargin = dp(18);
        card.addView(dismiss, btn);

        FrameLayout.LayoutParams center = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        center.leftMargin = dp(60);
        center.rightMargin = dp(60);
        root.addView(card, center);
        dismiss.requestFocus();
    }

    private void addText(LinearLayout parent, String s, int size, int color, boolean strong) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(size);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(4), dp(3), dp(4), dp(3));
        if (strong) tv.setTypeface(null, Typeface.BOLD);
        parent.addView(tv, new LinearLayout.LayoutParams(-1, -2));
    }

    private void clearTimers() {
        if (pending != null) handler.removeCallbacks(pending);
        if (expiry != null) handler.removeCallbacks(expiry);
        pending = null;
        expiry = null;
    }

    private void closeAndStop() {
        clearTimers();
        removeOverlay();
        stopSelf();
    }

    private void removeOverlay() {
        if (overlay != null) {
            try { windowManager.removeViewImmediate(overlay); }
            catch (Exception ignored) { }
            overlay = null;
        }
    }

    @Override public void onDestroy() {
        clearTimers();
        removeOverlay();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    private int dp(float x) { return Math.round(x * getResources().getDisplayMetrics().density); }
}
