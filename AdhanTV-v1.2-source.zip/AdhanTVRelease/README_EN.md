# Adhan TV v1.1 — custom Android TV dashboard and DreamService

This source updates the previously working household installation without changing application ID, SharedPreferences key, signing key or DreamService class.

New MainActivity displays DreamBoard, same as the system screensaver. Settings moved into SettingsActivity. It removes seconds and the address/compass from the dashboard; includes highlighted prayer cards and next prayer without seconds, and weather. Existing map, alarm overlay, media focus and audio volume features retained.

Build: upload `AdhanTV-v1.1-source.zip` at the repository root and create `.github/workflows/build-adhan-v1.1.yml` from the supplied workflow file. Run it on GitHub Actions. It fetches a short, unedited 1m27s adhan MP3 under CC BY-SA 4.0 from Wikimedia Commons (original uploader Atcovi), and creates a signed personal-use `app-debug.apk`. Source and licence: https://commons.wikimedia.org/wiki/File:The_Adhan_-_Muslim_Call_to_Prayer_-_Aaqib_Azeez.mp3 and https://creativecommons.org/licenses/by-sa/4.0/. The author is not affiliated with or endorsing this app.

VersionCode=5 (from v1.0=4). Keep existing installation to preserve settings. This archive was statically inspected but not compiled or tested on an Android TV device in this environment.
