package com.example.adhantv;

import android.service.dreams.DreamService;

/** Android's real system screensaver service; selection depends on Google TV firmware. */
public final class AdhanDreamService extends DreamService {
    private DreamBoard board;
    @Override public void onAttachedToWindow(){
        super.onAttachedToWindow();
        setInteractive(false);
        setFullscreen(true);
        setScreenBright(false);
        board=new DreamBoard(this);
        setContentView(board);
    }
    @Override public void onDreamingStarted(){
        super.onDreamingStarted();
        if(board!=null)board.start();
    }
    @Override public void onDreamingStopped(){
        if(board!=null)board.stop();
        super.onDreamingStopped();
    }
    @Override public void onDetachedFromWindow(){
        if(board!=null)board.stop();
        board=null;
        super.onDetachedFromWindow();
    }
}
