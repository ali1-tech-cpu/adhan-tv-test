package com.example.adhantv;

import android.content.Context;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PrayerRepository {
    private PrayerRepository() {}
    public static class Entry {
        public final String key, arabic;
        public final LocalDate day;
        public final LocalTime time;
        public final long millis;
        public Entry(String key, LocalDate day, LocalTime time, long millis) {
            this.key = key; this.arabic = Config.arabic(key); this.day=day; this.time=time; this.millis=millis;
        }
    }
    public static void fetch(Context c, LocalDate day) throws Exception {
        if (!Config.hasLocation(c)) throw new IllegalStateException("Location is not configured");
        String date=day.format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.US));
        String address = "https://api.aladhan.com/v1/timings/"+date+
            "?latitude="+Config.lat(c)+"&longitude="+Config.lon(c)+
            "&method="+Config.method(c)+"&school="+Config.school(c)+
            "&latitudeAdjustmentMethod="+Config.highLat(c); // Server resolves time zone from the coordinates.
        HttpURLConnection connection=(HttpURLConnection)new URL(address).openConnection();
        connection.setRequestMethod("GET"); connection.setConnectTimeout(4500); connection.setReadTimeout(4500);
        connection.setRequestProperty("Accept","application/json");
        try {
            if (connection.getResponseCode()!=200) throw new Exception("HTTP " + connection.getResponseCode());
            StringBuilder out = new StringBuilder();
            try (BufferedReader br=new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                String s; while((s=br.readLine())!=null) out.append(s);
            }
            JSONObject obj = new JSONObject(out.toString());
            if(obj.optInt("code")!=200) throw new Exception("API response not OK");
            JSONObject result=obj.getJSONObject("data");
            JSONObject t=result.getJSONObject("timings");
            String resolvedZone=result.getJSONObject("meta").optString("timezone", "");
            if(!resolvedZone.isEmpty()) {
                try { java.time.ZoneId.of(resolvedZone); Config.prefs(c).edit().putString("zone",resolvedZone).apply(); }
                catch(Exception ignored) {}
            }
            JSONObject selected=new JSONObject();
            for(String key:Config.PRAYERS) selected.put(key,parseTime(t.getString(key)).toString());
            // Keep only confirmed API times; never silently fabricate timings.
            c.getSharedPreferences("prayer_cache",Context.MODE_PRIVATE).edit()
                .putString(Config.cacheKey(c,day.toString()),selected.toString()).apply();
        } finally { connection.disconnect(); }
    }
    private static LocalTime parseTime(String api) {
        // AlAdhan may append a timezone, e.g. 06:22 (CEST).
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("^(\\d{1,2}):(\\d{2})").matcher(api.trim());
        if(!m.find()) throw new IllegalArgumentException("Invalid prayer time "+api);
        return LocalTime.of(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)));
    }
    public static List<Entry> day(Context c, LocalDate date) {
        List<Entry> list=new ArrayList<>();
        String raw=c.getSharedPreferences("prayer_cache",Context.MODE_PRIVATE)
            .getString(Config.cacheKey(c,date.toString()),null);
        if(raw==null) return list;
        try {
            JSONObject t=new JSONObject(raw);
            for(String key:Config.PRAYERS) {
                LocalTime time=LocalTime.parse(t.getString(key));
                long millis=ZonedDateTime.of(date,time,Config.zoneId(c)).toInstant().toEpochMilli();
                list.add(new Entry(key,date,time,millis));
            }
        } catch (Exception ex) { list.clear(); }
        return list;
    }
    public static Entry next(Context c,long now) {
        LocalDate today=LocalDate.now(Config.zoneId(c));
        for(int d=0;d<=2;d++) {
            for(Entry e:day(c,today.plusDays(d))) if(e.millis>now+2000) return e;
        }
        return null;
    }
    public static String refreshTodayAndTomorrow(Context c) {
        if(!Config.hasLocation(c)) return "اختر موقعك أولاً من الإعدادات";
        LocalDate today=LocalDate.now(Config.zoneId(c));
        // One fetch resolves the correct IANA time zone from geographic coordinates.
        try { fetch(c,today); today=LocalDate.now(Config.zoneId(c)); } catch(Exception ignored) {}
        int succeeded=0; String errors="";
        for(int d=0;d<=2;d++) {
            if(d==2 && day(c,today.plusDays(1)).size()==5) break;
            try { fetch(c,today.plusDays(d)); succeeded++; }
            catch(Exception e) { errors += (errors.isEmpty()?"":"؛ ")+"يوم "+d+": "+e.getMessage(); }
        }
        Scheduler.schedule(c);
        if (succeeded==0 && day(c,today).isEmpty()) return "فشل الاتصال بخدمة المواقيت: " + errors;
        return "تم تحديث " + succeeded + " يوم. " + (errors.isEmpty()?"":"بعض الأيام لم تُحدّث: "+errors);
    }
}
