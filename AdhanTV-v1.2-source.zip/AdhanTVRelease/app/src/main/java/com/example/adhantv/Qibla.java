package com.example.adhantv;

/** True bearing, clockwise from geographic north, using the great-circle initial course. */
public final class Qibla {
    private Qibla() {}
    private static final double KAABA_LAT=21.422487,KAABA_LON=39.826206;
    public static double bearing(double latitude,double longitude) {
        double a=Math.toRadians(latitude),b=Math.toRadians(KAABA_LAT);
        double d=Math.toRadians(KAABA_LON-longitude);
        double y=Math.sin(d)*Math.cos(b);
        double x=Math.cos(a)*Math.sin(b)-Math.sin(a)*Math.cos(b)*Math.cos(d);
        return (Math.toDegrees(Math.atan2(y,x))+360.0)%360.0;
    }
    public static String direction(double bearing) {
        String[] names={"الشمال","الشمال الشرقي","الشرق","الجنوب الشرقي","الجنوب","الجنوب الغربي","الغرب","الشمال الغربي"};
        return names[((int)Math.round(bearing/45.0))%8];
    }
}
