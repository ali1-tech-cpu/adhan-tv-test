package com.example.adhantv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** North-up OpenStreetMap tile preview with location pin and mathematically derived Qibla arrow.
 * Limited to visible tiles; caches files 7 days and identifies the application to tile servers. */
public final class QiblaMapView extends View {
    public interface ChangeListener {void onMove(double lat,double lon);}
    private static final int TILE=256;
    private static final long CACHE_MS=7L*86400*1000;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Map<String,Bitmap> loaded=new HashMap<>();
    private final Set<String> pending=new HashSet<>();
    private final Map<String,Long> failed=new HashMap<>();
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private final File tileCache;
    private ChangeListener changed;
    private int zoom=16;
    private double latitude, longitude;

    public QiblaMapView(Context context,double lat,double lon) {
        super(context); latitude=lat; longitude=lon;
        tileCache=new File(context.getCacheDir(),"osm_visible_tiles");
        if(!tileCache.exists())tileCache.mkdirs();
        setFocusable(true);setFocusableInTouchMode(true);
    }
    public void setChangeListener(ChangeListener l){changed=l;}
    public double lat(){return latitude;}
    public double lon(){return longitude;}
    public void setZoom(int z){
        int newZoom=Math.max(12,Math.min(19,z));
        if(newZoom==zoom)return;
        zoom=newZoom;loaded.clear();failed.clear();invalidate();
    }
    public int getZoom(){return zoom;}
    public void movePixels(int dx,int dy) {
        double worldX=longitudeToX(longitude,zoom)+dx;
        double worldY=latitudeToY(latitude,zoom)+dy;
        double sz=TILE*Math.pow(2,zoom);
        longitude=worldX/sz*360.0-180.0;
        latitude=Math.toDegrees(Math.atan(Math.sinh(Math.PI*(1-2*worldY/sz))));
        latitude=Math.max(-85.0,Math.min(85.0,latitude));
        if(changed!=null)changed.onMove(latitude,longitude);
        invalidate();
    }
    private static double longitudeToX(double lon,int z){return (lon+180)/360.0*TILE*Math.pow(2,z);}
    private static double latitudeToY(double lat,int z){
        double rad=Math.toRadians(Math.max(-85,Math.min(85,lat)));
        return (1-Math.log(Math.tan(rad)+1/Math.cos(rad))/Math.PI)/2*TILE*Math.pow(2,z);
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width=getWidth(),height=getHeight();
        canvas.drawColor(0xFF203441);
        double centerX=longitudeToX(longitude,zoom),centerY=latitudeToY(latitude,zoom);
        int left=(int)Math.floor((centerX-width/2.0)/TILE);
        int right=(int)Math.floor((centerX+width/2.0)/TILE);
        int top=(int)Math.floor((centerY-height/2.0)/TILE);
        int bottom=(int)Math.floor((centerY+height/2.0)/TILE);
        int max=(1<<zoom);
        for(int ty=top;ty<=bottom;ty++){
            if(ty<0||ty>=max)continue;
            for(int tx=left;tx<=right;tx++){
                int wrapped=((tx%max)+max)%max;
                int x=(int)Math.round(width/2.0+tx*TILE-centerX);
                int y=(int)Math.round(height/2.0+ty*TILE-centerY);
                String key=zoom+"_"+wrapped+"_"+ty;
                Bitmap bmp=loaded.get(key);
                if(bmp!=null&&!bmp.isRecycled()){
                    paint.setColor(Color.WHITE);paint.setStyle(Paint.Style.FILL);paint.setAlpha(255);
                    canvas.drawBitmap(bmp,x,y,paint);
                }else{
                    paint.setColor(0xFF35505A);paint.setStyle(Paint.Style.FILL);
                    canvas.drawRect(x,y,x+TILE,y+TILE,paint);
                    getTile(key,zoom,wrapped,ty);
                }
            }
        }
        int cx=width/2,cy=height/2;
        double heading=Qibla.bearing(latitude,longitude);
        double a=Math.toRadians(heading-90);
        float px=(float)(cx+Math.cos(a)*140),py=(float)(cy+Math.sin(a)*140);
        paint.setStrokeWidth(11);paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(0xFF20313D);canvas.drawLine(cx,cy,px,py,paint);
        paint.setColor(0xFFF1BD55);paint.setStrokeWidth(7);canvas.drawLine(cx,cy,px,py,paint);
        float wing=24;
        Path tip=new Path();tip.moveTo(px,py);
        tip.lineTo((float)(px-Math.cos(a)*wing+Math.cos(a+Math.PI/2)*wing*.5),
            (float)(py-Math.sin(a)*wing+Math.sin(a+Math.PI/2)*wing*.5));
        tip.lineTo((float)(px-Math.cos(a)*wing-Math.cos(a+Math.PI/2)*wing*.5),
            (float)(py-Math.sin(a)*wing-Math.sin(a+Math.PI/2)*wing*.5));tip.close();
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xFFF1BD55);canvas.drawPath(tip,paint);
        paint.setColor(0xFF0C2633);canvas.drawCircle(cx,cy,16,paint);
        paint.setColor(Color.WHITE);canvas.drawCircle(cx,cy,8,paint);
        paint.setColor(0xDA132735);canvas.drawRoundRect(10,10,122,65,12,12,paint);
        paint.setColor(Color.WHITE);paint.setTextSize(24);
        canvas.drawText("N ↑",30,44,paint);
        paint.setColor(0xD7102230);
        canvas.drawRect(0,height-33,width,height,paint);
        paint.setTextSize(15);paint.setColor(Color.WHITE);
        canvas.drawText("© OpenStreetMap contributors",12,height-11,paint);
    }
    private void getTile(String key,int z,int x,int y){
        if(pending.contains(key))return;
        if(System.currentTimeMillis()-failed.getOrDefault(key,0L)<5*60*1000L)return;
        pending.add(key);
        network.submit(()->{
            Bitmap bmp=null;
            try{
                File saved=new File(tileCache,key+".png");
                if(saved.isFile() && System.currentTimeMillis()-saved.lastModified() < CACHE_MS) {
                    bmp=BitmapFactory.decodeFile(saved.getAbsolutePath());
                }else{
                    URL u=new URL(String.format(Locale.US,"https://tile.openstreetmap.org/%d/%d/%d.png",z,x,y));
                    HttpURLConnection http=(HttpURLConnection)u.openConnection();
                    http.setConnectTimeout(6000);http.setReadTimeout(6000);
                    http.setRequestProperty("User-Agent","AdhanTV-PrivateHomeDisplay/0.3 (Android TV)");
                    try{
                        if(http.getResponseCode()==200){
                            try(java.io.InputStream in=http.getInputStream();FileOutputStream out=new FileOutputStream(saved)){
                                byte[] buffer=new byte[8192];int n;
                                while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
                            }
                            bmp=BitmapFactory.decodeFile(saved.getAbsolutePath());
                        }else if(saved.isFile())bmp=BitmapFactory.decodeFile(saved.getAbsolutePath());
                    }finally{http.disconnect();}
                }
            }catch(Exception ignored){}
            final Bitmap result=bmp;
            post(()->{
                pending.remove(key);
                if(result!=null){loaded.put(key,result);failed.remove(key);}
                else failed.put(key,System.currentTimeMillis());
                invalidate();
            });
        });
    }
    @Override protected void onDetachedFromWindow(){super.onDetachedFromWindow();network.shutdownNow();}
}
