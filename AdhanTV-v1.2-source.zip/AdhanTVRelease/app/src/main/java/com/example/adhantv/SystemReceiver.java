package com.example.adhantv;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SystemReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent intent) {
        final PendingResult pending=goAsync();
        Context app=c.getApplicationContext();
        new Thread(() -> {
            try { Scheduler.schedule(app); PrayerRepository.refreshTodayAndTomorrow(app);
                try { WeatherRepository.refresh(app,false); } catch(Exception ignored) {} }
            catch(Exception ignored) { Scheduler.schedule(app); }
            finally { pending.finish(); }
        },"adhan-tv-system").start();
    }
}
