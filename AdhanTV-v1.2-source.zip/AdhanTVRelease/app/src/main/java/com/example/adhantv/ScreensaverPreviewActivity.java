package com.example.adhantv;

import android.app.Activity;
import android.os.Bundle;

/** Preview the same dashboard without requiring ADB or changing system ambient settings. */
public final class ScreensaverPreviewActivity extends Activity {
    private DreamBoard board;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        board=new DreamBoard(this);setContentView(board);
    }
    @Override public void onResume(){super.onResume();if(board!=null)board.start();}
    @Override public void onPause(){if(board!=null)board.stop();super.onPause();}
}
