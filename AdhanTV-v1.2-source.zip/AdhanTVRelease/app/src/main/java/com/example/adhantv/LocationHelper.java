package com.example.adhantv;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;

/** One-shot, user-consented network-based location for TVs (GPS not required).
 * Never requests background location or continuous tracking. */
public final class LocationHelper {
    private LocationHelper() {}
    public interface Result { void onResult(Location location, String error); }
    public static boolean permitted(Activity a) {
        return a.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    public static void requestPermission(Activity a,int requestCode){
        a.requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},requestCode);
    }
    public static void getOnce(Activity a, Result done){
        if(!permitted(a)){done.onResult(null,"يرجى السماح بالموقع أولاً");return;}
        LocationManager lm=(LocationManager)a.getSystemService(Context.LOCATION_SERVICE);
        if(lm==null){done.onResult(null,"خدمة الموقع غير متوفرة على هذا الجهاز");return;}
        String provider=LocationManager.NETWORK_PROVIDER;
        try {
            if(!lm.getAllProviders().contains(provider) || !lm.isProviderEnabled(provider)) {
                done.onResult(null,"تحديد الموقع عبر الشبكة غير متاح على الجهاز. استخدم الخريطة أو المدينة يدوياً.");return;
            }
            Handler main=new Handler(Looper.getMainLooper());
            Location cached=lm.getLastKnownLocation(provider);
            if(Build.VERSION.SDK_INT>=30){
                CancellationSignal cancel=new CancellationSignal();
                final boolean[] completed={false};
                Runnable timeout=()->{
                    if(completed[0])return;completed[0]=true;cancel.cancel();
                    if(cached!=null) done.onResult(cached,null);
                    else done.onResult(null,"لم يرسل التلفزيون موقعه. حدد موقعك يدوياً بالخريطة.");
                };
                main.postDelayed(timeout,12000);
                Executor executor=main::post;
                lm.getCurrentLocation(provider,cancel,executor,location->{
                    if(completed[0])return;completed[0]=true;main.removeCallbacks(timeout);
                    if(location!=null)done.onResult(location,null);
                    else if(cached!=null)done.onResult(cached,null);
                    else done.onResult(null,"لم يتمكن التلفزيون من تحديد الموقع. اختر المدينة أو الموقع على الخريطة.");
                });
            }else if(cached!=null){done.onResult(cached,null);}
            else done.onResult(null,"الموقع غير متوفر على هذا الجهاز. حدده على الخريطة.");
        }catch(SecurityException e){done.onResult(null,"لم يُمنح إذن الموقع.");}
        catch(Exception e){done.onResult(null,"تعذّر تحديد الموقع تلقائياً: "+e.getMessage());}
    }
}
