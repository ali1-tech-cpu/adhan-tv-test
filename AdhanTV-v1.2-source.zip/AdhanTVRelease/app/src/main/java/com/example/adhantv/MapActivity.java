package com.example.adhantv;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** D-pad navigation: arrows move map while map has focus, OK enters controls.
 * Controls remain reachable and operate with ordinary OK like the other TV buttons. */
public final class MapActivity extends Activity {
    private QiblaMapView map;
    private TextView instructions;
    private Button zoomIn, zoomOut, mapMode;
    private boolean swallowCenterKeyUp=false;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,8,18,8);root.setBackgroundColor(0xFF0A1C2A);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        instructions=new TextView(this);instructions.setTextColor(0xFFF1C97E);instructions.setTextSize(19);
        instructions.setGravity(Gravity.CENTER);root.addView(instructions);
        map=new QiblaMapView(this,Config.lat(this),Config.lon(this));
        root.addView(map,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setGravity(Gravity.CENTER);
        LinearLayout zoomRow=new LinearLayout(this);zoomRow.setGravity(Gravity.CENTER);
        LinearLayout saveRow=new LinearLayout(this);saveRow.setGravity(Gravity.CENTER);
        zoomIn=button("تكبير +",()->zoom(1));
        zoomOut=button("تصغير −",()->zoom(-1));
        mapMode=button("تحريك الخريطة بالأسهم",()->map.requestFocus());
        Button select=button("حفظ موقع البيت",this::savePoint);
        Button exit=button("إغلاق",this::finish);
        zoomRow.addView(zoomIn);zoomRow.addView(zoomOut);zoomRow.addView(mapMode);
        saveRow.addView(select);saveRow.addView(exit);
        controls.addView(zoomRow);controls.addView(saveRow);
        root.addView(controls);setContentView(root);
        map.setChangeListener((lat,lon)->updateLabel());updateLabel();map.requestFocus();
    }
    private Button button(String title,Runnable onClick){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(16);
        b.setFocusable(true);
        b.setOnClickListener(v->onClick.run());return b;
    }
    private void zoom(int delta){
        int before=map.getZoom();map.setZoom(before+delta);
        updateLabel();
        Toast.makeText(this,"تكبير الخريطة: مستوى "+map.getZoom()+" من 19",Toast.LENGTH_SHORT).show();
    }
    private void updateLabel(){
        double heading=Qibla.bearing(map.lat(),map.lon());
        instructions.setText(String.format(Locale.US,
            "القبلة: %.1f° من الشمال الحقيقي (%s) • الخريطة شمالها للأعلى • OK للتحكم بالتكبير • مستوى %d/19 • %.5f, %.5f",
            heading,Qibla.direction(heading),map.getZoom(),map.lat(),map.lon()));
    }
    private void savePoint(){
        Config.prefs(this).edit().putString("lat",String.valueOf(map.lat()))
            .putString("lon",String.valueOf(map.lon()))
            .putString("city","موقع محدد على الخريطة").apply();
        Scheduler.schedule(this);
        Toast.makeText(this,"تم حفظ الموقع. عد إلى الإعدادات لتحديث المواقيت والطقس.",Toast.LENGTH_LONG).show();
        finish();
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        // Avoid forwarding the same OK key-up to a newly focused zoom button.
        if(swallowCenterKeyUp && event.getAction()==KeyEvent.ACTION_UP){
            int key=event.getKeyCode();
            if(key==KeyEvent.KEYCODE_DPAD_CENTER || key==KeyEvent.KEYCODE_ENTER){
                swallowCenterKeyUp=false;return true;
            }
        }
        if(map!=null && event.getAction()==KeyEvent.ACTION_DOWN){
            int code=event.getKeyCode();
            // Hardware keyboard +/- or dedicated zoom keys, even if focus is on a button.
            if(code==KeyEvent.KEYCODE_PLUS || code==KeyEvent.KEYCODE_EQUALS ||
                code==KeyEvent.KEYCODE_ZOOM_IN || code==KeyEvent.KEYCODE_NUMPAD_ADD){ zoom(1); return true; }
            if(code==KeyEvent.KEYCODE_MINUS || code==KeyEvent.KEYCODE_ZOOM_OUT ||
                code==KeyEvent.KEYCODE_NUMPAD_SUBTRACT){ zoom(-1); return true; }
            if(map.hasFocus()){
                if(code==KeyEvent.KEYCODE_DPAD_UP){map.movePixels(0,-38);return true;}
                if(code==KeyEvent.KEYCODE_DPAD_DOWN){map.movePixels(0,38);return true;}
                if(code==KeyEvent.KEYCODE_DPAD_LEFT){map.movePixels(-38,0);return true;}
                if(code==KeyEvent.KEYCODE_DPAD_RIGHT){map.movePixels(38,0);return true;}
                // Previously OK saved the pin; it now enters reachable focusable zoom controls.
                if(code==KeyEvent.KEYCODE_DPAD_CENTER || code==KeyEvent.KEYCODE_ENTER){
                    swallowCenterKeyUp=true;zoomIn.requestFocus();return true;
                }
            }
        }
        return super.dispatchKeyEvent(event);
    }
}
