package com.example.adhantv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

/** Home screen is the very same live dashboard that powers the screensaver. */
public class MainActivity extends Activity {
    private DreamBoard dashboard;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
        FrameLayout root=new FrameLayout(this);
        dashboard=new DreamBoard(this);
        root.addView(dashboard,new FrameLayout.LayoutParams(-1,-1));
        Button settings=new Button(this);
        settings.setText("⚙");settings.setAllCaps(false);
        settings.setTextColor(0xFFF7E4BC);settings.setTextSize(22);
        settings.setFocusable(true);
        settings.setBackground(buttonBg(false));
        settings.setOnFocusChangeListener((v,has)->settings.setBackground(buttonBg(has)));
        settings.setOnClickListener(v->openSettings());
        FrameLayout.LayoutParams pos=new FrameLayout.LayoutParams(dp(45),dp(45),Gravity.TOP|Gravity.RIGHT);
        pos.setMargins(0,dp(86),dp(22),0);
        root.addView(settings,pos);setContentView(root);
        settings.requestFocus();
        if(!Config.hasLocation(this) && !Config.prefs(this).getBoolean("location_intro_shown",false)){
            Config.prefs(this).edit().putBoolean("location_intro_shown",true).apply();
            settings.postDelayed(this::openSettings,400);
        }
    }
    private GradientDrawable buttonBg(boolean focus){
        GradientDrawable g=new GradientDrawable();g.setCornerRadius(dp(16));
        g.setColor(focus?0xFF305B5B:0xB51E3E48);
        g.setStroke(dp(focus?2:1),focus?0xFFF1CD86:0xFF446B6A);return g;
    }
    private void openSettings(){startActivity(new Intent(this,SettingsActivity.class));}
    @Override protected void onResume(){super.onResume();if(dashboard!=null)dashboard.start();}
    @Override protected void onPause(){if(dashboard!=null)dashboard.stop();super.onPause();}
    @Override public boolean onKeyUp(int key,KeyEvent event){
        // Remote's menu key is a shortcut even when the settings button isn't focused.
        if(key==KeyEvent.KEYCODE_MENU){openSettings();return true;}
        return super.onKeyUp(key,event);
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
