package com.example.adhantv;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.time.LocalDate;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        final PendingResult pending=goAsync();
        final Context c=context.getApplicationContext();
        final String action=intent==null?"":intent.getAction();
        new Thread(() -> {
            try {
                if(Scheduler.ACTION_PRAYER.equals(action) && Config.enabled(c)) {
                    long now=System.currentTimeMillis();
                    LocalDate today=LocalDate.now(Config.zoneId(c));
                    for(PrayerRepository.Entry e: PrayerRepository.day(c,today)) {
                        long diff=now-e.millis;
                        if(diff>=0 && diff<15*60*1000L) {
                            // Never deliver the same time twice (e.g. clock change/reboot).
                            String unique=e.day+"_"+e.key;
                            String last=Config.prefs(c).getString("last_trigger","");
                            if(!unique.equals(last)) {
                                Config.prefs(c).edit().putString("last_trigger",unique).apply();
                                Intent start=new Intent(c,OverlayService.class);
                                start.putExtra(OverlayService.EXTRA_PRAYER,e.key);
                                start.putExtra(OverlayService.EXTRA_TIME,e.time.toString());
                                start.putExtra(OverlayService.EXTRA_DEMO,false);
                                if(Build.VERSION.SDK_INT>=26) c.startForegroundService(start);
                                else c.startService(start);
                            }
                            break;
                        }
                    }
                    Scheduler.schedule(c);
                } else if(Scheduler.ACTION_WEATHER.equals(action)) {
                    try { WeatherRepository.refresh(c,false); }catch(Exception ignored){}
                    Scheduler.schedule(c);
                } else {
                    PrayerRepository.refreshTodayAndTomorrow(c);
                    try { WeatherRepository.refresh(c,false); }catch(Exception ignored){}
                }
            } catch(Exception ignored) { Scheduler.schedule(c); }
            finally { pending.finish(); }
        },"adhan-tv-schedule").start();
    }
}
