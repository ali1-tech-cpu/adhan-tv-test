package com.example.adhantv;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;

public final class Scheduler {
    private Scheduler() {}
    public static final String ACTION_PRAYER="com.example.adhantv.PRAYER";
    public static final String ACTION_REFRESH="com.example.adhantv.REFRESH";
    public static final String ACTION_WEATHER="com.example.adhantv.WEATHER";
    private static PendingIntent intent(Context c,String action,int request) {
        Intent i=new Intent(c,ReminderReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(c,request,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    }
    public static boolean precise(Context c) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        return Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms();
    }
    public static synchronized void schedule(Context c) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent prayer=intent(c,ACTION_PRAYER,201), refresh=intent(c,ACTION_REFRESH,202), weather=intent(c,ACTION_WEATHER,203);
        am.cancel(prayer); am.cancel(refresh); am.cancel(weather);
        if (!Config.enabled(c)) return;
        long now=System.currentTimeMillis();
        PrayerRepository.Entry next=PrayerRepository.next(c,now);
        if(next!=null) scheduleOne(c,am,prayer,next.millis);
        ZonedDateTime refreshTime=ZonedDateTime.of(
            LocalDate.now(Config.zoneId(c)),LocalTime.of(1,5),Config.zoneId(c));
        if(refreshTime.toInstant().toEpochMilli()<=now+60000)
            refreshTime=refreshTime.plusDays(1);
        scheduleOne(c,am,refresh,refreshTime.toInstant().toEpochMilli());
        // When no upcoming cached prayer exists, retry fetching in 30 min.
        if(next==null) scheduleOne(c,am,refresh,now+30*60*1000L);
        scheduleOne(c,am,weather,now+45*60*1000L);
    }
    private static void scheduleOne(Context c,AlarmManager am,PendingIntent pi,long time) {
        if(time<=System.currentTimeMillis()) return;
        if(precise(c)) {
            try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pi); return; }
            catch(SecurityException ignored) { }
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pi);
    }
}
