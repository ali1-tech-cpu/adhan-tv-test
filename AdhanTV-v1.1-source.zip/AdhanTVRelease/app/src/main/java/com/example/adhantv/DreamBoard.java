package com.example.adhantv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/** One shared 16:9 TV dashboard for the home screen, preview and real DreamService.
 * No second counter, address, or compass on the dashboard. All data stay local/cached. */
public final class DreamBoard extends FrameLayout {
    private static final int BASE=0xFF081721, PANEL=0xFF112B38, BORDER=0xFF31505A;
    private static final int GOLD=0xFFF1CD86, WHITE=0xFFF6F8F3, MUTED=0xFF9EB9BF;
    private static final int AQUA=0xFF81C9BC;
    private final Context app;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final TextView clock, date, weather, nextName, nextTime, remaining, subtitle;
    private final TextView[] titles=new TextView[5], values=new TextView[5], hints=new TextView[5];
    private final LinearLayout[] prayerCards=new LinearLayout[5];
    private final LinearLayout surface;
    private boolean active, fetching;
    private long nextFetch;
    private int lastPaintMinute=-1;
    private final Runnable ticker=new Runnable(){ @Override public void run(){
        if(!active)return;
        render();
        handler.postDelayed(this,15000);
    }};

    public DreamBoard(Context c){
        super(c); app=c.getApplicationContext();
        setBackgroundColor(BASE);
        addView(new AmbientBackground(c),new FrameLayout.LayoutParams(-1,-1));
        surface=new LinearLayout(c);surface.setOrientation(LinearLayout.VERTICAL);
        surface.setPadding(px(88),px(50),px(88),px(44));
        FrameLayout.LayoutParams full=new FrameLayout.LayoutParams(-1,-1);
        addView(surface,full);

        // Slim header: app identity on the right, weather on the left.
        LinearLayout header=new LinearLayout(c);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView brand=txt("✦  أذان التلفزيون",35,GOLD,true,Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        header.addView(brand,new LinearLayout.LayoutParams(0,-1,1));
        weather=txt("الطقس الآن  —",28,WHITE,false,Gravity.CENTER);
        weather.setPadding(px(24),0,px(24),0);
        weather.setBackground(rounded(0xB51A3440,px(28),0xFF3A6266,1));
        header.addView(weather,new LinearLayout.LayoutParams(-2,px(62)));
        surface.addView(header,new LinearLayout.LayoutParams(-1,px(78)));

        // Quiet hero; no seconds: readable at a distance.
        LinearLayout hero=new LinearLayout(c);
        hero.setOrientation(LinearLayout.VERTICAL);hero.setGravity(Gravity.CENTER);
        TextView eyebrow=txt("الوقت الآن",27,AQUA,false,Gravity.CENTER);
        hero.addView(eyebrow,new LinearLayout.LayoutParams(-1,px(48)));
        clock=txt("--:--",162,WHITE,true,Gravity.CENTER);
        clock.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));
        clock.setIncludeFontPadding(false);
        clock.setLetterSpacing(0.035f);
        hero.addView(clock,new LinearLayout.LayoutParams(-1,px(185)));
        date=txt("",37,MUTED,false,Gravity.CENTER);
        hero.addView(date,new LinearLayout.LayoutParams(-1,px(60)));
        surface.addView(hero,new LinearLayout.LayoutParams(-1,0,1));

        // Featured next-prayer strip.
        LinearLayout heroPrayer=new LinearLayout(c);heroPrayer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        heroPrayer.setGravity(Gravity.CENTER_VERTICAL);heroPrayer.setOrientation(LinearLayout.HORIZONTAL);
        heroPrayer.setPadding(px(45),px(12),px(45),px(12));
        heroPrayer.setBackground(rounded(0xE3153540,px(26),0xFF8D8167,2));
        LinearLayout prayerNameColumn=new LinearLayout(c);
        prayerNameColumn.setOrientation(LinearLayout.VERTICAL);prayerNameColumn.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        subtitle=txt("الصلاة القادمة",29,AQUA,false,Gravity.RIGHT);
        prayerNameColumn.addView(subtitle);
        nextName=txt("—",55,WHITE,true,Gravity.RIGHT);
        prayerNameColumn.addView(nextName);
        heroPrayer.addView(prayerNameColumn,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout prayerTimeColumn=new LinearLayout(c);
        prayerTimeColumn.setOrientation(LinearLayout.VERTICAL);prayerTimeColumn.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
        nextTime=txt("--:--",50,GOLD,true,Gravity.LEFT);
        prayerTimeColumn.addView(nextTime);
        remaining=txt("",26,MUTED,false,Gravity.LEFT);
        prayerTimeColumn.addView(remaining);
        heroPrayer.addView(prayerTimeColumn,new LinearLayout.LayoutParams(0,-1,1));
        surface.addView(heroPrayer,new LinearLayout.LayoutParams(-1,px(178)));

        gap(22);
        LinearLayout sectionTitle=new LinearLayout(c);sectionTitle.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sectionTitle.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=txt("مواقيت الصلاة",32,WHITE,true,Gravity.RIGHT);
        sectionTitle.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        TextView side=txt("اليوم",24,MUTED,false,Gravity.LEFT);
        sectionTitle.addView(side,new LinearLayout.LayoutParams(0,-1,1));
        surface.addView(sectionTitle,new LinearLayout.LayoutParams(-1,px(49)));
        gap(12);

        LinearLayout prayerRow=new LinearLayout(c);
        prayerRow.setOrientation(LinearLayout.HORIZONTAL);prayerRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final String[] names={"الفجر","الظهر","العصر","المغرب","العشاء"};
        for(int i=0;i<5;i++){
            LinearLayout card=new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);
            card.setPadding(px(12),px(18),px(12),px(14));
            card.setBackground(rounded(PANEL,px(25),BORDER,1));
            hints[i]=txt("◦",26,AQUA,false,Gravity.CENTER);
            card.addView(hints[i],new LinearLayout.LayoutParams(-1,px(26)));
            titles[i]=txt(names[i],29,MUTED,true,Gravity.CENTER);
            card.addView(titles[i],new LinearLayout.LayoutParams(-1,px(54)));
            values[i]=txt("--:--",45,WHITE,true,Gravity.CENTER);
            card.addView(values[i],new LinearLayout.LayoutParams(-1,px(64)));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1);
            cp.setMargins(px(7),0,px(7),0);
            prayerRow.addView(card,cp);prayerCards[i]=card;
        }
        surface.addView(prayerRow,new LinearLayout.LayoutParams(-1,px(184)));
        gap(10);
        LinearLayout footer=new LinearLayout(c);footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView foot=txt("◈    لحظات هادئة، ومواقيت واضحة",22,0xFF7899A1,false,Gravity.CENTER);
        footer.addView(foot,new LinearLayout.LayoutParams(-1,-1));
        surface.addView(footer,new LinearLayout.LayoutParams(-1,px(52)));
        render();
    }
    private void gap(int h){surface.addView(new View(getContext()),new LinearLayout.LayoutParams(1,px(h)));}
    private int px(float sourcePx){
        android.util.DisplayMetrics m=getResources().getDisplayMetrics();
        float k=Math.min(m.widthPixels/1920f,m.heightPixels/1080f);
        return Math.max(1,Math.round(sourcePx*k));
    }
    private TextView txt(String label,int fontPx,int color,boolean bold,int gravity){
        TextView t=new TextView(getContext());t.setText(label);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX,px(fontPx));
        t.setTextColor(color);t.setGravity(gravity);
        if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        t.setIncludeFontPadding(false);t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return t;
    }
    private GradientDrawable rounded(int color,int radius,int strokeColor,int strokeWidth){
        GradientDrawable g=new GradientDrawable();g.setColor(color);
        g.setCornerRadius(radius);g.setStroke(px(strokeWidth),strokeColor);return g;
    }
    public void start(){if(active)return;active=true;handler.removeCallbacks(ticker);handler.post(ticker);checkData();}
    public void stop(){active=false;handler.removeCallbacks(ticker);}
    public void refreshNow(){render();checkData();}
    private void checkData(){
        if(fetching || System.currentTimeMillis()<nextFetch)return;
        nextFetch=System.currentTimeMillis()+10*60*1000;
        LocalDate today=LocalDate.now(Config.zoneId(app));
        boolean missing=PrayerRepository.day(app,today).size()!=5 ||
            PrayerRepository.day(app,today.plusDays(1)).size()!=5;
        if(!missing && WeatherRepository.isFresh(app))return;
        fetching=true;
        new Thread(()->{
            try{
                if(missing)PrayerRepository.refreshTodayAndTomorrow(app);
                if(!WeatherRepository.isFresh(app))WeatherRepository.refresh(app,false);
            }catch(Exception ignored){}finally{
                fetching=false;
                handler.post(()->{if(active)render();});
            }
        },"adhan-dashboard-sync").start();
    }
    private void render(){
        ZonedDateTime now=ZonedDateTime.now(Config.zoneId(app));
        int minute=(int)(System.currentTimeMillis()/60000);
        clock.setText(now.format(DateTimeFormatter.ofPattern("HH:mm",Locale.US)));
        date.setText(now.format(DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy",new Locale("ar"))));
        String w=WeatherRepository.display(app).replace("الطقس: ","");
        if(w.length()>30)w=w.substring(0,30)+"…";
        weather.setText(w);
        List<PrayerRepository.Entry> entries=PrayerRepository.day(app,now.toLocalDate());
        PrayerRepository.Entry next=PrayerRepository.next(app,System.currentTimeMillis());
        if(next==null){
            nextName.setText("بانتظار تحديث المواقيت");nextTime.setText("--:--");remaining.setText("افتح الإعدادات للتحديث");
        }else{
            nextName.setText(next.arabic);
            nextTime.setText(next.time.format(DateTimeFormatter.ofPattern("HH:mm",Locale.US)));
            long minutes=Math.max(0,(next.millis-System.currentTimeMillis()+59999)/60000);
            remaining.setText(relative(minutes));
        }
        for(int i=0;i<5;i++){
            if(i<entries.size())values[i].setText(entries.get(i).time.format(DateTimeFormatter.ofPattern("HH:mm",Locale.US)));
            else values[i].setText("--:--");
            boolean focus=next!=null && next.day.equals(now.toLocalDate()) && next.key.equals(Config.PRAYERS[i]);
            prayerCards[i].setBackground(rounded(focus?0xFF27443F:PANEL,px(25),focus?GOLD:BORDER,focus?2:1));
            titles[i].setTextColor(focus?GOLD:MUTED);
            hints[i].setText(focus?"✦":"◦");hints[i].setTextColor(focus?GOLD:AQUA);
        }
        // Minute-scale imperceptible drift protects the screen while idle.
        if(minute!=lastPaintMinute){
            lastPaintMinute=minute;
            surface.setTranslationX(px((int)(4*Math.sin(minute/8.0))));
            surface.setTranslationY(px((int)(3*Math.cos(minute/9.0))));
        }
        if(active && System.currentTimeMillis()>nextFetch)checkData();
    }
    private static String relative(long total){
        long h=total/60,m=total%60;
        if(h>0 && m>0)return "بعد "+(h==1?"ساعة":h+" ساعات")+" و"+m+" دقيقة";
        if(h>0)return "بعد "+(h==1?"ساعة":h+" ساعات");
        return m==0?"الآن":"بعد "+m+" دقيقة";
    }
    private static final class AmbientBackground extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        AmbientBackground(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);
            int w=getWidth(),h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,new int[]{0xFF081A24,0xFF102A34,0xFF061219},null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);p.setShader(null);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1,w/1900f));
            p.setColor(0x1535D5B2);
            for(int i=0;i<6;i++) c.drawCircle(w*.90f,h*.13f, w*(.12f+i*.045f),p);
            p.setColor(0x0EF1CD86);
            for(int i=0;i<4;i++) c.drawCircle(w*.05f,h*.95f,w*(.10f+i*.055f),p);
            p.setStyle(Paint.Style.FILL);
        }
    }
}
